import { ShoppingBag, X, ChevronRight, Receipt } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import type { MenuItem } from "@shared/schema";
import { Button } from "@/components/ui/button";

interface CartItem {
  menuItem: MenuItem;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: number, quantity: number) => void;
  onCheckout: () => void;
  isPending: boolean;
}

export function CartDrawer({ 
  isOpen, 
  onClose, 
  items, 
  onUpdateQuantity, 
  onCheckout,
  isPending
}: CartDrawerProps) {
  const totalAmount = items.reduce((sum, item) => sum + (item.menuItem.price * item.quantity), 0);
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col border-l"
          >
            {/* Header */}
            <div className="p-6 border-b flex items-center justify-between bg-secondary/20">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-full">
                  <ShoppingBag className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-display font-bold">Your Order</h2>
                  <p className="text-sm text-muted-foreground">{totalItems} items selected</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-muted rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>

            {/* Items List */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
                  <ShoppingBag className="w-16 h-16 text-muted-foreground/30" />
                  <p className="font-medium text-lg">Your cart is empty</p>
                  <p className="text-sm text-muted-foreground">Add some delicious items to get started!</p>
                </div>
              ) : (
                items.map(({ menuItem, quantity }) => (
                  <motion.div 
                    layout
                    key={menuItem.id} 
                    className="flex gap-4 items-start group"
                  >
                    <div className="w-16 h-16 rounded-xl bg-secondary/50 flex items-center justify-center shrink-0 text-xl font-bold text-muted-foreground/50">
                      {menuItem.category === 'deal' ? '★' : menuItem.name.charAt(0)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-semibold text-foreground truncate pr-2">{menuItem.name}</h4>
                        <span className="font-bold text-foreground">{menuItem.price * quantity}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{menuItem.price} PKR each</p>
                      
                      <div className="flex items-center gap-3">
                        <div className="flex items-center border rounded-lg bg-background">
                          <button 
                            onClick={() => onUpdateQuantity(menuItem.id, quantity - 1)}
                            className="px-3 py-1 hover:bg-secondary rounded-l-lg transition-colors"
                          >
                            -
                          </button>
                          <span className="w-8 text-center text-sm font-medium">{quantity}</span>
                          <button 
                            onClick={() => onUpdateQuantity(menuItem.id, quantity + 1)}
                            className="px-3 py-1 hover:bg-secondary rounded-r-lg transition-colors"
                          >
                            +
                          </button>
                        </div>
                        <button 
                          onClick={() => onUpdateQuantity(menuItem.id, 0)}
                          className="text-xs text-red-500 hover:text-red-700 font-medium opacity-0 group-hover:opacity-100 transition-opacity ml-auto"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="p-6 bg-secondary/10 border-t space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Subtotal</span>
                    <span>{totalAmount} PKR</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold text-foreground">
                    <span>Total Bill</span>
                    <span>{totalAmount} PKR</span>
                  </div>
                </div>
                
                <Button 
                  onClick={onCheckout}
                  disabled={isPending}
                  className="w-full h-14 text-lg font-semibold rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 flex items-center justify-center gap-2"
                >
                  {isPending ? (
                    "Placing Order..." 
                  ) : (
                    <>
                      Place Order <ChevronRight className="w-5 h-5" />
                    </>
                  )}
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
