import { motion } from "framer-motion";
import { Plus, Minus, Utensils, Pizza, Coffee, Beer, Flame, Star, ShoppingBag } from "lucide-react";
import type { MenuItem } from "@shared/schema";

interface MenuCardProps {
  item: MenuItem;
  quantity: number;
  onUpdateQuantity: (newQuantity: number) => void;
}

const getIcon = (name: string, category: string) => {
  const lowerName = name.toLowerCase();
  const lowerCat = category.toLowerCase();
  
  if (lowerCat === 'deal' || lowerName.includes('deal')) return <Flame className="w-8 h-8 text-orange-500" />;
  if (lowerName.includes('burger')) return <Utensils className="w-8 h-8 text-amber-600" />;
  if (lowerName.includes('pizza')) return <Pizza className="w-8 h-8 text-red-500" />;
  if (lowerName.includes('drink')) return <Beer className="w-8 h-8 text-blue-500" />;
  if (lowerName.includes('coffee')) return <Coffee className="w-8 h-8 text-brown-500" />;
  if (lowerName.includes('salad')) return <div className="text-green-600 font-bold text-2xl">🥗</div>;
  if (lowerName.includes('fries')) return <div className="text-yellow-500 font-bold text-2xl">🍟</div>;
  
  return <ShoppingBag className="w-8 h-8 text-primary" />;
};

export function MenuCard({ item, quantity, onUpdateQuantity }: MenuCardProps) {
  const isSelected = quantity > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className={`
        relative overflow-hidden rounded-2xl bg-white border p-6
        transition-all duration-300 shadow-sm hover:shadow-lg
        ${isSelected ? 'border-primary ring-1 ring-primary/20' : 'border-border/50'}
      `}
    >
      <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
        {getIcon(item.name, item.category)}
      </div>

      <div className="flex items-start justify-between mb-4">
        <div className="p-3 rounded-xl bg-secondary/50 text-foreground">
          {getIcon(item.name, item.category)}
        </div>
        <div className="text-lg font-bold text-primary">
          {item.price} PKR
        </div>
      </div>

      <h3 className="text-lg font-bold text-foreground mb-1 leading-tight font-display">
        {item.name}
      </h3>
      <p className="text-sm text-muted-foreground mb-6 line-clamp-2 min-h-[2.5rem]">
        {item.description || "A delicious choice prepared fresh for you."}
      </p>

      {/* Controls */}
      <div className="flex items-center justify-between mt-auto">
        {isSelected ? (
          <div className="flex items-center gap-3 w-full bg-secondary/30 p-1 rounded-lg">
            <button
              onClick={() => onUpdateQuantity(Math.max(0, quantity - 1))}
              className="p-2 rounded-md hover:bg-white hover:shadow-sm transition-all text-foreground"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="flex-1 text-center font-semibold tabular-nums text-lg">
              {quantity}
            </span>
            <button
              onClick={() => onUpdateQuantity(quantity + 1)}
              className="p-2 rounded-md bg-white shadow-sm hover:shadow-md transition-all text-primary"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => onUpdateQuantity(1)}
            className="w-full py-2.5 rounded-lg bg-foreground text-background font-medium hover:bg-primary hover:text-white transition-all duration-300 flex items-center justify-center gap-2 group"
          >
            Add to Order
            <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" />
          </button>
        )}
      </div>
      
      {item.category === 'deal' && (
        <div className="absolute top-4 right-4">
          <span className="px-2 py-1 bg-accent text-accent-foreground text-xs font-bold rounded-full uppercase tracking-wider flex items-center gap-1">
            <Star className="w-3 h-3 fill-current" /> Special
          </span>
        </div>
      )}
    </motion.div>
  );
}
