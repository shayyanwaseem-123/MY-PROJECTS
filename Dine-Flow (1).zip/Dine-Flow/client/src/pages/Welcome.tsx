import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, ChefHat, UtensilsCrossed } from "lucide-react";

export default function Welcome() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/5 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2" />

      {/* Navigation (Simple) */}
      <nav className="relative z-10 px-6 py-6 md:px-12 flex justify-between items-center">
        <div className="flex items-center gap-2 font-display font-bold text-2xl tracking-tight">
          <div className="w-10 h-10 bg-foreground text-white rounded-xl flex items-center justify-center">
            <ChefHat className="w-6 h-6" />
          </div>
          SnackYard
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-foreground leading-[1.1]">
            Experience the <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-600">
              Taste of Quality
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Welcome to our premium dining experience. From handcrafted burgers to authentic Italian pasta, 
            we serve perfection on every plate.
          </p>

          <div className="pt-8">
            <Link 
              href="/order/new" 
              className="group inline-flex items-center gap-3 bg-foreground text-background px-8 py-5 rounded-full text-lg font-semibold shadow-2xl hover:bg-primary hover:text-white hover:scale-105 transition-all duration-300"
            >
              Start New Order
              <div className="bg-white/20 p-1 rounded-full group-hover:bg-white/30 transition-colors">
                <ArrowRight className="w-5 h-5" />
              </div>
            </Link>
          </div>
        </motion.div>
      </main>

      {/* Footer Decoration */}
      <div className="relative z-10 w-full overflow-hidden opacity-5 pointer-events-none">
        <div className="flex items-center justify-center gap-12 animate-marquee whitespace-nowrap py-12">
          {Array(10).fill(0).map((_, i) => (
            <div key={i} className="flex items-center gap-12">
              <span className="text-8xl font-display font-black text-foreground">BURGER</span>
              <UtensilsCrossed className="w-16 h-16" />
              <span className="text-8xl font-display font-black text-transparent stroke-text">PIZZA</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
