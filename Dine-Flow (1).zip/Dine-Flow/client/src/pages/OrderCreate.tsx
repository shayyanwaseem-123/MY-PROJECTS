import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { ShoppingBag, ChevronLeft, Search } from "lucide-react";
import { useMenu } from "@/hooks/use-menu";
import { useCreateOrder } from "@/hooks/use-orders";
import { MenuCard } from "@/components/MenuCard";
import { CartDrawer } from "@/components/CartDrawer";
import { useToast } from "@/hooks/use-toast";
import type { MenuItem } from "@shared/schema";

// Schema for customer details step
const customerSchema = z.object({
  customerName: z.string().min(2, "Name is required"),
  customerNic: z.string().min(5, "NIC is required"),
  customerPhone: z.string().min(10, "Valid phone number required"),
});

type CustomerForm = z.infer<typeof customerSchema>;

export default function OrderCreate() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { data: menuItems, isLoading } = useMenu();
  const createOrder = useCreateOrder();
  
  const [step, setStep] = useState<1 | 2>(1);
  const [cart, setCart] = useState<Map<number, number>>(new Map()); // itemId -> quantity
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const form = useForm<CustomerForm>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      customerName: "",
      customerNic: "",
      customerPhone: "",
    }
  });

  const handleCustomerSubmit = (data: CustomerForm) => {
    setStep(2);
    // Smooth scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const updateQuantity = (itemId: number, quantity: number) => {
    setCart(prev => {
      const next = new Map(prev);
      if (quantity <= 0) {
        next.delete(itemId);
      } else {
        next.set(itemId, quantity);
      }
      return next;
    });
  };

  const handleCheckout = async () => {
    const customerData = form.getValues();
    const items = Array.from(cart.entries()).map(([menuItemId, quantity]) => ({
      menuItemId,
      quantity,
    }));

    if (items.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your order first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const order = await createOrder.mutateAsync({
        ...customerData,
        items,
      });
      
      toast({
        title: "Order Placed!",
        description: `Order #${order.id} has been created successfully.`,
      });
      
      setLocation(`/order/${order.id}`);
    } catch (error: any) {
      toast({
        title: "Failed to place order",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Derived state
  const categories = menuItems ? ["all", ...new Set(menuItems.map(i => i.category))] : [];
  
  const filteredItems = menuItems?.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const cartItems = menuItems 
    ? Array.from(cart.entries()).map(([id, quantity]) => ({
        menuItem: menuItems.find(i => i.id === id)!,
        quantity
      })).filter(i => i.menuItem)
    : [];
    
  const totalItemsCount = Array.from(cart.values()).reduce((a, b) => a + b, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30 pb-32">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {step === 2 && (
              <button 
                onClick={() => setStep(1)}
                className="p-2 hover:bg-muted rounded-full transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}
            <h1 className="font-display font-bold text-xl">
              {step === 1 ? "Customer Details" : "Select Menu Items"}
            </h1>
          </div>
          
          {step === 2 && (
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 hover:bg-muted rounded-full transition-colors"
            >
              <ShoppingBag className="w-6 h-6 text-foreground" />
              {totalItemsCount > 0 && (
                <span className="absolute top-0 right-0 w-5 h-5 bg-primary text-white text-xs font-bold rounded-full flex items-center justify-center ring-2 ring-white">
                  {totalItemsCount}
                </span>
              )}
            </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* STEP 1: Customer Form */}
        {step === 1 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-xl mx-auto"
          >
            <div className="bg-white rounded-2xl shadow-sm border p-8">
              <h2 className="text-2xl font-display font-bold mb-6">Who are we serving today?</h2>
              
              <form onSubmit={form.handleSubmit(handleCustomerSubmit)} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                  <input
                    {...form.register("customerName")}
                    className="w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    placeholder="e.g. John Doe"
                  />
                  {form.formState.errors.customerName && (
                    <p className="text-red-500 text-sm">{form.formState.errors.customerName.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">National ID (NIC)</label>
                  <input
                    {...form.register("customerNic")}
                    className="w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    placeholder="e.g. 12345-1234567-1"
                  />
                  {form.formState.errors.customerNic && (
                    <p className="text-red-500 text-sm">{form.formState.errors.customerNic.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Phone Number</label>
                  <input
                    {...form.register("customerPhone")}
                    type="tel"
                    className="w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    placeholder="e.g. 0300-1234567"
                  />
                  {form.formState.errors.customerPhone && (
                    <p className="text-red-500 text-sm">{form.formState.errors.customerPhone.message}</p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-primary text-primary-foreground font-bold rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  Start Ordering
                </button>
              </form>
            </div>
          </motion.div>
        )}

        {/* STEP 2: Menu Selection */}
        {step === 2 && (
          <div className="space-y-8">
            {/* Controls Bar */}
            <div className="flex flex-col md:flex-row gap-4 justify-between items-center sticky top-20 z-20 bg-muted/95 backdrop-blur py-4 -mx-4 px-4 rounded-xl">
              {/* Category Pills */}
              <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-2 md:pb-0 scrollbar-hide">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`
                      px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all
                      ${selectedCategory === cat 
                        ? 'bg-foreground text-background shadow-lg' 
                        : 'bg-white border text-muted-foreground hover:bg-white/80'}
                    `}
                  >
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </button>
                ))}
              </div>

              {/* Search */}
              <div className="relative w-full md:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search menu..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-full border bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
            </div>

            {/* Menu Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems?.map((item) => (
                <MenuCard
                  key={item.id}
                  item={item}
                  quantity={cart.get(item.id) || 0}
                  onUpdateQuantity={(qty) => updateQuantity(item.id, qty)}
                />
              ))}
            </div>
            
            {filteredItems?.length === 0 && (
              <div className="text-center py-20 text-muted-foreground">
                <p className="text-lg">No items found matching your search.</p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Cart Summary Bar (Mobile Only) */}
      {step === 2 && totalItemsCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t md:hidden z-40">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-foreground text-background py-4 rounded-xl font-bold flex items-center justify-between px-6 shadow-lg"
          >
            <div className="flex items-center gap-2">
              <span className="bg-primary text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">
                {totalItemsCount}
              </span>
              <span>View Order</span>
            </div>
            <span>
              {cartItems.reduce((sum, { menuItem, quantity }) => sum + (menuItem.price * quantity), 0)} PKR
            </span>
          </button>
        </div>
      )}

      {/* Cart Drawer */}
      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onCheckout={handleCheckout}
        isPending={createOrder.isPending}
      />
    </div>
  );
}
