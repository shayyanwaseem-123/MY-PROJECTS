import { useRoute, Link } from "wouter";
import { useOrder } from "@/hooks/use-orders";
import { CheckCircle2, Home, Printer, Share2 } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function OrderReceipt() {
  const [match, params] = useRoute("/order/:id");
  const orderId = parseInt(params?.id || "0");
  const { data: order, isLoading, error } = useOrder(orderId);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-muted rounded-full" />
          <div className="w-32 h-4 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4 text-center p-4">
        <h2 className="text-2xl font-bold text-destructive">Order Not Found</h2>
        <p className="text-muted-foreground">We couldn't find the receipt you're looking for.</p>
        <Link href="/">
          <Button variant="outline">Return Home</Button>
        </Link>
      </div>
    );
  }

  const formattedDate = new Date(order.createdAt!).toLocaleString('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  return (
    <div className="min-h-screen bg-muted/50 py-12 px-4 sm:px-6">
      <div className="max-w-lg mx-auto space-y-8">
        
        {/* Success Message */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center space-y-4"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 text-green-600 mb-2">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h1 className="text-3xl font-display font-bold text-foreground">Order Confirmed!</h1>
          <p className="text-muted-foreground">Thank you for dining with us.</p>
        </motion.div>

        {/* Receipt Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden border border-border/50"
        >
          {/* Receipt Header */}
          <div className="bg-foreground text-white p-8 text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary via-accent to-primary" />
            <h2 className="font-display font-bold text-2xl tracking-widest uppercase mb-1">SnackYard</h2>
            <p className="text-white/60 text-sm">Fine Dining & Takeaway</p>
          </div>

          <div className="p-8 space-y-8">
            {/* Meta Info */}
            <div className="flex justify-between text-sm border-b pb-6 border-dashed">
              <div className="space-y-1">
                <p className="text-muted-foreground">Order Number</p>
                <p className="font-mono font-bold text-lg">#{order.id.toString().padStart(4, '0')}</p>
              </div>
              <div className="space-y-1 text-right">
                <p className="text-muted-foreground">Date & Time</p>
                <p className="font-medium">{formattedDate}</p>
              </div>
            </div>

            {/* Customer Info */}
            <div className="grid grid-cols-2 gap-4 text-sm bg-secondary/30 p-4 rounded-lg">
              <div>
                <p className="text-muted-foreground text-xs uppercase tracking-wide">Customer</p>
                <p className="font-semibold">{order.customerName}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs uppercase tracking-wide">Phone</p>
                <p className="font-mono">{order.customerPhone}</p>
              </div>
            </div>

            {/* Order Items */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Order Details</h3>
              <div className="space-y-3">
                {order.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-start text-sm group">
                    <div className="flex gap-3">
                      <span className="font-mono font-bold w-6 text-muted-foreground">{item.quantity}x</span>
                      <div>
                        <p className="font-medium text-foreground">{item.menuItem.name}</p>
                        <p className="text-xs text-muted-foreground">{item.price} PKR each</p>
                      </div>
                    </div>
                    <span className="font-medium tabular-nums">{item.price * item.quantity} PKR</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="border-t-2 border-dashed pt-6 space-y-2">
              <div className="flex justify-between items-end">
                <p className="font-display font-bold text-2xl">Total Bill</p>
                <p className="font-display font-bold text-3xl text-primary">{order.totalAmount} PKR</p>
              </div>
              <p className="text-xs text-center text-muted-foreground mt-8">
                Please retain this receipt for your records.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Link href="/">
            <Button variant="outline" className="w-full gap-2 h-12 text-base">
              <Home className="w-4 h-4" /> Go Home
            </Button>
          </Link>
          <Button 
            onClick={() => window.print()}
            className="w-full gap-2 h-12 text-base bg-foreground text-background hover:bg-foreground/90"
          >
            <Printer className="w-4 h-4" /> Print Receipt
          </Button>
        </div>

      </div>
    </div>
  );
}
