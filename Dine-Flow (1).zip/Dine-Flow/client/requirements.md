## Packages
framer-motion | Animations for page transitions and micro-interactions
lucide-react | Icons for menu items and UI elements
zod | Schema validation
react-hook-form | Form handling
@hookform/resolvers | Zod resolver for react-hook-form

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
