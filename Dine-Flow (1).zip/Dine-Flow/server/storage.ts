import { db } from "./db";
import { menuItems, orders, orderItems, type MenuItem, type CreateOrderRequest, type Order } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getMenuItems(): Promise<MenuItem[]>;
  createOrder(order: CreateOrderRequest): Promise<Order>;
  getOrder(id: number): Promise<Order & { items: any[] } | undefined>;
  seedMenu(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getMenuItems(): Promise<MenuItem[]> {
    return await db.select().from(menuItems);
  }

  async createOrder(orderReq: CreateOrderRequest): Promise<Order> {
    const items = await this.getMenuItems();
    let total = 0;
    const orderItemsData: any[] = [];

    for (const itemReq of orderReq.items) {
      const item = items.find(i => i.id === itemReq.menuItemId);
      if (item) {
        total += item.price * itemReq.quantity;
        orderItemsData.push({
          menuItemId: item.id,
          quantity: itemReq.quantity,
          price: item.price
        });
      }
    }

    const [newOrder] = await db.insert(orders).values({
      customerName: orderReq.customerName,
      customerNic: orderReq.customerNic,
      customerPhone: orderReq.customerPhone,
      totalAmount: total,
    }).returning();

    for (const itemData of orderItemsData) {
        await db.insert(orderItems).values({
            orderId: newOrder.id,
            ...itemData
        });
    }

    return newOrder;
  }

  async getOrder(id: number): Promise<Order & { items: any[] } | undefined> {
    const order = await db.query.orders.findFirst({
        where: eq(orders.id, id),
        with: {
            items: {
                with: {
                    menuItem: true
                }
            }
        }
    });
    return order;
  }

  async seedMenu(): Promise<void> {
    const existing = await this.getMenuItems();
    if (existing.length === 0) {
      await db.insert(menuItems).values([
        { name: "Burger", price: 500, category: "item", description: "Delicious juicy burger" },
        { name: "Pizza", price: 1200, category: "item", description: "Cheesy pepperoni pizza" },
        { name: "Pasta", price: 800, category: "item", description: "Creamy alfredo pasta" },
        { name: "Salad", price: 300, category: "item", description: "Fresh garden salad" },
        { name: "Drink", price: 100, category: "item", description: "Chilled soft drink" },
        { name: "Fries", price: 200, category: "item", description: "Crispy french fries" },
        { name: "Deal1: Burger + Fries + Drink", price: 700, category: "deal", description: "Burger, Fries, and a Drink" },
        { name: "Deal2: Pizza + Drink", price: 1300, category: "deal", description: "Pizza and a Drink" },
        { name: "HottestDeal: 2 Burgers + 2 Fries + 2 Drinks", price: 1400, category: "deal", description: "Double the fun! Save 400 PKR + extra 10% off" },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
